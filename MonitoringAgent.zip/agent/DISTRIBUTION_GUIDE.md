# 🚀 Agent Distribution Guide (For IT Admins)

## 📦 How to Distribute the Agent to Employees

### **Option 1: Zip File Distribution (Recommended)**

1. **Create a distribution package:**
   ```bash
   cd "/Users/stalin_j/monitor copy"
   zip -r MonitoringAgent.zip agent/ -x "agent/venv/*" -x "agent/.env" -x "agent/__pycache__/*" -x "agent/*.log"
   ```

2. **Share `MonitoringAgent.zip` with employees** via:
   - Email
   - Shared drive
   - Company portal
   - USB drive

3. **Employees extract and run:**
   ```bash
   unzip MonitoringAgent.zip
   cd agent
   ./install.sh
   ```

---

### **Option 2: Network Share**

1. **Place agent folder on network drive:**
   ```
   \\company-server\software\MonitoringAgent\
   ```

2. **Employees copy to their computer:**
   - Copy folder to Desktop
   - Run `./install.sh`

---

### **Option 3: Automated Deployment (Advanced)**

Create a deployment script that:
1. Downloads agent from server
2. Runs installation automatically
3. Configures with company API URL

---

## 📋 What Employees Need

### **Minimum Requirements:**
- **macOS** 10.14+ / **Windows** 10+ / **Linux** (Ubuntu 18.04+)
- **Python 3.8+** (installer will check)
- **Internet connection**
- **5 MB disk space**

### **Permissions (macOS):**
- Screen Recording
- Accessibility

### **Permissions (Windows):**
- Administrator rights (for first install only)

---

## 🔧 Pre-Configuration (Optional)

You can pre-configure the API URL for employees:

1. **Edit `agent/.env.example`:**
   ```env
   API_URL=https://your-company-server.com/api
   ```

2. **Modify `get_token.py`** to use this as default:
   ```python
   api_url = input("API URL (press Enter for https://your-company-server.com/api): ").strip()
   if not api_url:
       api_url = "https://your-company-server.com/api"
   ```

---

## 📝 Employee Instructions Template

Send this to employees:

```
Subject: Install Monitoring Agent

Hi Team,

Please install the employee monitoring agent on your work laptop:

1. Download: [Link to MonitoringAgent.zip]
2. Extract the zip file
3. Open Terminal and run:
   cd ~/Downloads/agent
   ./install.sh
4. Enter your work email and password when prompted
5. A shortcut will appear on your Desktop

Daily use:
- Double-click "StartMonitoring.command" on Desktop
- Login to dashboard
- Click "Start Monitoring"

Questions? Contact IT Support.
```

---

## 🔒 Security Notes

- **JWT tokens** are stored locally in `.env` (employee's computer only)
- **Monitoring credentials** are stored encrypted on server
- **Screenshots** are uploaded via HTTPS
- **No passwords** are stored in plain text

---

## 📊 Monitoring Deployment

### **Track Installation:**
- Check employee login activity in admin dashboard
- Monitor active sessions
- Verify screenshot uploads

### **Common Issues:**

| Issue | Solution |
|-------|----------|
| Python not installed | Provide Python installer link |
| Permission errors | Guide to System Preferences |
| Token expired | Employee runs `get_token.py` again |
| No screenshots | Check agent is running + permissions granted |

---

## 🎯 Deployment Checklist

- [ ] Server is running and accessible
- [ ] API URL is configured correctly
- [ ] Agent package is created (zip file)
- [ ] Employee instructions are prepared
- [ ] IT support is ready to help
- [ ] Test installation on one employee first
- [ ] Roll out to all employees
- [ ] Monitor first day for issues

---

## 📞 Support

For technical issues, check:
- `agent/agent.log` - Agent logs
- Backend server logs
- Employee dashboard for session status

---

**Ready to deploy!** 🚀
