# 👤 Employee Monitoring Agent - Setup Guide

## 🎯 What This Does

This agent runs on your laptop and:
- ✅ Captures screenshots when monitoring is active
- ✅ Logs your application activity
- ✅ Automatically starts/stops based on dashboard
- ✅ **No manual configuration needed!**

---

## 🚀 Quick Start (3 Steps)

### Step 1: One-Time Setup

Open Terminal and run:

```bash
cd "/Users/stalin_j/monitor copy/agent"
source venv/bin/activate
python3 get_token.py
```

**What it asks:**
- API URL: Press Enter (uses default)
- Your Email: `your.email@company.com`
- Your Password: `your_password`
- Save to .env? Type `y` and press Enter

**Done!** This only needs to be done once.

---

### Step 2: Start the Agent

Every time you want to work, run:

```bash
cd "/Users/stalin_j/monitor copy/agent"
source venv/bin/activate
./start_agent.sh
```

Or simply:

```bash
python3 monitor_agent.py
```

**The agent will:**
- ✅ Connect to the server
- ✅ Open your dashboard automatically
- ✅ Wait for you to start monitoring

---

### Step 3: Use the Dashboard

1. **Login** to the dashboard (it opens automatically)
2. **Enter monitoring credentials** (if first time)
3. **Click "Start Monitoring"**
4. **Work normally** - agent captures automatically!
5. **Click "Stop Monitoring"** when done

---

## 📋 Daily Workflow

### Morning:
```bash
# Start the agent
cd "/Users/stalin_j/monitor copy/agent"
source venv/bin/activate
python3 monitor_agent.py
```

### In Dashboard:
1. Login
2. Click "Start Monitoring"
3. Work normally

### Evening:
1. Click "Stop Monitoring" in dashboard
2. Press Ctrl+C in terminal to stop agent

---

## ❓ FAQ

### Q: Do I need to enter credentials in .env?
**A: No!** You only need your JWT token (from `get_token.py`). Monitoring credentials are entered in the dashboard.

### Q: What if my token expires?
**A: Run `python3 get_token.py` again to get a new token.**

### Q: Can I close the terminal?
**A: No**, the agent needs to run in the terminal. Minimize it instead.

### Q: What if I forget to start the agent?
**A: No screenshots will be captured.** Always start the agent before clicking "Start Monitoring" in the dashboard.

### Q: Where are screenshots stored?
**A: On the server.** You can view them in your dashboard.

---

## 🔧 Troubleshooting

### Agent won't start
```bash
# Re-run setup
python3 get_token.py
```

### "No credentials stored" error
1. Go to dashboard
2. Click "Start Monitoring"
3. Enter your monitoring credentials in the popup
4. Try again

### Permission errors (macOS)
1. Go to **System Preferences** → **Security & Privacy** → **Privacy**
2. Grant permissions for:
   - **Screen Recording** (for screenshots)
   - **Accessibility** (for activity tracking)

---

## 📞 Need Help?

Contact your system administrator or IT support.

---

**That's it! Simple and automatic.** 🎉
