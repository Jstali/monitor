# 📦 Employee Monitoring Agent - Installation Guide

## 🎯 For Employees: How to Install & Use

### **Step 1: Download the Agent Folder**

Your IT admin will provide you with the `agent` folder. Save it to your computer (e.g., Desktop or Documents).

---

### **Step 2: One-Time Installation**

1. **Open Terminal** (Applications → Utilities → Terminal)

2. **Navigate to the agent folder:**
   ```bash
   cd ~/Desktop/agent
   ```
   (Change path if you saved it elsewhere)

3. **Run the installer:**
   ```bash
   ./install.sh
   ```

4. **Follow the prompts:**
   - API URL: Press Enter (uses default)
   - Your Email: Enter your work email
   - Your Password: Enter your password
   - Save to .env? Type `y` and press Enter

5. **Done!** A shortcut will be created on your Desktop.

---

### **Step 3: Daily Use**

#### **Option A: Desktop Shortcut (Easiest)**

1. **Double-click** `StartMonitoring.command` on your Desktop
2. Dashboard opens automatically
3. Click **"Start Monitoring"** button
4. Work normally!

#### **Option B: Terminal**

```bash
cd ~/Desktop/agent
./start_monitoring.sh
```

---

## 📋 Daily Workflow

### **Morning (Start Work):**
1. Double-click `StartMonitoring.command` on Desktop
2. Dashboard opens in browser
3. Login if needed
4. Click **"Start Monitoring"**
5. Minimize the terminal window (don't close it!)

### **During Work:**
- Work normally
- Agent captures screenshots automatically
- Don't close the terminal window

### **Evening (End Work):**
1. Go to dashboard
2. Click **"Stop Monitoring"**
3. Close the terminal window (or press Ctrl+C)

---

## ❓ Common Questions

### Q: Do I need to install anything?
**A:** Just run `./install.sh` once. It installs everything automatically.

### Q: Where do I enter my monitoring credentials?
**A:** In the **web dashboard**, not in any files! When you click "Start Monitoring" for the first time, it will ask for credentials.

### Q: What if I restart my computer?
**A:** Just double-click `StartMonitoring.command` again.

### Q: Can I work offline?
**A:** No, the agent needs internet connection to send data to the server.

### Q: What if I see "Permission Denied"?
**A:** Run: `chmod +x install.sh start_monitoring.sh`

---

## 🔧 Troubleshooting

### Error: "Python not found"
**Solution:** Install Python from https://www.python.org/downloads/

### Error: "No module named 'requests'"
**Solution:** Run `./install.sh` again

### Error: "Permission denied" (macOS)
**Solution:**
1. System Preferences → Security & Privacy → Privacy
2. Enable **Screen Recording** for Terminal
3. Enable **Accessibility** for Terminal

### Error: "Token expired"
**Solution:**
1. Open Terminal
2. `cd ~/Desktop/agent`
3. `source venv/bin/activate`
4. `python3 get_token.py`
5. Enter your credentials again

---

## 📞 Need Help?

Contact IT Support or your system administrator.

---

## 🎉 That's It!

**Installation:** Run `./install.sh` once  
**Daily Use:** Double-click `StartMonitoring.command`  
**Simple!**
